import os
import json
import sys
import traceback


try:
    env_options = os.environ.get("WINGS_ENGINE_PATCH_OPTIONS")

    if env_options:
        from .registry import enable
        
        try:
            # Expected format: {"vllm_ascend": ["soft_fp8", ...], ...}
            options = json.loads(env_options)
            
            if isinstance(options, dict):
                for inference_engine, features in options.items():
                    if isinstance(features, list) and features:
                        enable(inference_engine, features)
            else:
                print("[Wings Engine Patch] Warning: WINGS_ENGINE_PATCH_OPTIONS must be a JSON dictionary.", file=sys.stderr)
                
        except json.JSONDecodeError as e:
            print(f"[Wings Engine Patch] Warning: Failed to parse WINGS_ENGINE_PATCH_OPTIONS: {e}", file=sys.stderr)
except Exception:
    print("[Wings Engine Patch] Critical Error during auto-patching:", file=sys.stderr)
    traceback.print_exc(file=sys.stderr)
