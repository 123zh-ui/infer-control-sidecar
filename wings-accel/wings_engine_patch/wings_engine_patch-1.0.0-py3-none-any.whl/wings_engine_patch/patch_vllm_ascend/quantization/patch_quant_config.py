import wrapt


def _AscendQuantConfig_is_layer_skipped_ascend_wrapper(
    wrapped,
    instance,
    args,
    kwargs
):
    prefix, fused_mapping = args
    self = instance

    proj_name = prefix.split(".")[-1]
    if proj_name in fused_mapping:
        shard_prefixes = [
            prefix.replace(proj_name, shard_proj_name)
            for shard_proj_name in fused_mapping[proj_name]
        ]

        is_skipped = None
        for shard_prefix in shard_prefixes:
            is_shard_skipped = self.quant_description[shard_prefix +
                                                        '.weight'] in ["FLOAT", "BFLOAT16", "FLOAT16"]

            if is_skipped is None:
                is_skipped = is_shard_skipped
            elif is_shard_skipped != is_skipped:
                raise ValueError(
                    f"Detected some but not all shards of {prefix} "
                    "are quantized. All shards of fused layers "
                    "to have the same precision.")
    else:
        is_skipped = self.quant_description[prefix + '.weight'] in ["FLOAT", "BFLOAT16", "FLOAT16"]

    assert is_skipped is not None
    return is_skipped


def patch_AscendQuantConfig():
    wrapt.register_post_import_hook(
        lambda m: wrapt.wrap_function_wrapper(
            'vllm_ascend.quantization.quant_config',
            'AscendQuantConfig.is_layer_skipped_ascend',
            _AscendQuantConfig_is_layer_skipped_ascend_wrapper
        ),
        'vllm_ascend.quantization.quant_config'
    )


def _AscendLinearMethod_create_weights_wrapper(
    wrapped,
    instance,
    args,
    kwargs
):
    self = instance
    if hasattr(self.quant_method, 'create_weights'):
        self.quant_method.create_weights(*args, **kwargs)
        return
    return wrapped(*args, **kwargs)


def patch_AscendLinearMethod():
    wrapt.register_post_import_hook(
        lambda m: wrapt.wrap_function_wrapper(
            'vllm_ascend.quantization.quant_config',
            'AscendLinearMethod.create_weights',
            _AscendLinearMethod_create_weights_wrapper
        ),
        'vllm_ascend.quantization.quant_config'
    )
