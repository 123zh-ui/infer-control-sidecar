from typing import Any, Callable, Dict, Optional, Tuple, Union, List

import torch
import torch_npu
from vllm.config import CompilationMode, get_current_vllm_config

from vllm.distributed import get_ep_group
from vllm.forward_context import get_forward_context

from vllm_ascend.ascend_config import get_ascend_config
from vllm_ascend.distributed.parallel_state import get_mc2_group
from vllm_ascend.ops.fused_moe.experts_selector import select_experts
from ..ops import fp8_ops
from vllm.model_executor.utils import set_weight_attrs
from vllm.model_executor.layers.fused_moe import (FusedMoeWeightScaleSupported)
from vllm.model_executor.parameter import (BlockQuantScaleParameter)
from vllm.model_executor.layers.quantization.utils.fp8_utils import (
    create_fp8_scale_parameter,
    create_fp8_weight_parameter,
    validate_fp8_block_shape)

def ceil(x, y):
    return (x + y - 1) // y

class AscendW8A16FP8LinearMethod:

    def __init__(self):
        self.weight_block_size = (128, 128)

    def create_weights(
        self,
        layer: torch.nn.Module,
        input_size_per_partition: int,
        output_partition_sizes: List[int],
        input_size: int,
        output_size: int,
        params_dtype: torch.dtype,
        **extra_weight_attrs,
    ) -> None:
        # adapted from vllm.model_executor.layers.quantization.fp8.FP8LinearMethod.create_weights
        output_size_per_partition = sum(output_partition_sizes)
        # When using FP8 quantization, all Linear classes in vllm prefer using weight_loader_v2 if available.
        weight_loader = getattr(layer, 'weight_loader_v2', None) or extra_weight_attrs.get('weight_loader')

        layer.logical_widths = output_partition_sizes
        layer.input_size_per_partition = input_size_per_partition
        layer.output_size_per_partition = output_size_per_partition
        layer.orig_dtype = params_dtype
        layer.weight_block_size = self.weight_block_size

        validate_fp8_block_shape(layer, input_size, output_size,
                                    input_size_per_partition,
                                    output_partition_sizes,
                                    self.weight_block_size)

        weight = create_fp8_weight_parameter(output_size_per_partition,
                                                input_size_per_partition,
                                                weight_loader)
        layer.register_parameter("weight", weight)
        
        scale = create_fp8_scale_parameter(BlockQuantScaleParameter,
                                            output_partition_sizes,
                                            input_size_per_partition,
                                            self.weight_block_size,
                                            weight_loader)
        set_weight_attrs(scale, {"scale_type": "weight_scale"})
        layer.register_parameter("weight_scale_inv", scale)
        # set tp_rank & tp_size for weight and weight_scale_inv
        layer.update_param_tp_status()


    @staticmethod
    def apply(
        layer: torch.nn.Module,
        x: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
        bias: Optional[torch.Tensor] = None,
        tp_rank: Optional[int] = 0,
    ) -> torch.Tensor:
        return fp8_ops.fp8_matmul(x, layer.weight.data, layer.weight_scale_inv.data)

    def process_weights_after_loading(self, layer):
        layer.weight.data = layer.weight.data.view(torch.uint8)
        layer.weight_scale_inv.data = layer.weight_scale_inv.data.to(torch.float32)
        layer.weight.data, layer.weight_scale_inv.data = fp8_ops.optimize_weight_layout_for_fp8_matmul(
            layer.weight.data, layer.weight_scale_inv.data)
        
        # Replace with plain nn.Parameter to avoid torch.compile issues with custom Parameter classes
        layer.weight = torch.nn.Parameter(layer.weight.data, requires_grad=False)
        layer.weight_scale_inv = torch.nn.Parameter(layer.weight_scale_inv.data, requires_grad=False)
