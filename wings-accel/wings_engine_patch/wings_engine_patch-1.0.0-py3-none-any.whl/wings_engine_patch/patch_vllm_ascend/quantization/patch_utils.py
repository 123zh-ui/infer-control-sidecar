import wrapt


def patch_ASCEND_QUANTIZATION_METHOD_MAP():
    def update_map(m):
        from vllm_ascend.quantization.utils import ASCEND_QUANTIZATION_METHOD_MAP
        from .w8a16fp8 import AscendW8A16FP8LinearMethod
        ASCEND_QUANTIZATION_METHOD_MAP['W8A16FP8'] = {
            "linear": AscendW8A16FP8LinearMethod,
        }

    wrapt.register_post_import_hook(
        update_map,
        'vllm_ascend.quantization.utils'
    )
