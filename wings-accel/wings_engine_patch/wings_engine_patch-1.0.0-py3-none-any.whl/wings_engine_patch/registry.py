import importlib
from typing import List

# Define patches with module path and function/class name for lazy loading
# Format: ('module_path', 'member_name')
_registered_patches = {
    ('vllm_ascend', 'soft_fp8'): [
        ('wings_engine_patch.patch_vllm_ascend.quantization.patch_utils', 'patch_ASCEND_QUANTIZATION_METHOD_MAP'),
        ('wings_engine_patch.patch_vllm_ascend.quantization.patch_quant_config', 'patch_AscendQuantConfig'),
        ('wings_engine_patch.patch_vllm_ascend.quantization.patch_quant_config', 'patch_AscendLinearMethod'),
    ],
    ('vllm', 'test_patch'): [
         ('wings_engine_patch.patch_vllm.test_patch', 'patch_vllm_report_kv_cache_config'),
    ]
}

def get_patches(inference_engine: str, feature: str):
    patch_defs = _registered_patches.get((inference_engine, feature), [])
    patches = []
    for module_path, member_name in patch_defs:
        try:
            module = importlib.import_module(module_path)
            patches.append(getattr(module, member_name))
        except (ImportError, AttributeError) as e:
            print(f"[Wings Accel] Error loading patch {member_name} from {module_path}: {e}")
    return patches


def enable(inference_engine: str, features: List[str]):
    print(f"Enabling patches for inference_engine={inference_engine}, features={features}")
    for feature in features:
        patches = get_patches(inference_engine, feature)
        for patch in patches:
            patch()
